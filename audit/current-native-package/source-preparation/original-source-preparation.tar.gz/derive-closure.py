from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,traceback
F=Path('/Users/master/cyber/.worktrees/selfhost-0.4-finalization-20261002');R=F/'current-distribution';OUT=R/'measurements/production-closure';OUT.mkdir()
nu=F/'distribution/local-macos-rust189/temporary/cyber-candidate/nu/nu-0.112.2-aarch64-apple-darwin/nu'
spec=json.loads((R/'trisha-native-ci/.github/current-package-inputs.json').read_text());report=dict(scope='Exact production Cargo closure derivation before source export',status='running',commands=[])
env=dict(os.environ)
for key in list(env):
 if key.startswith(('GH_','GITHUB_','TRIDENT_','GIT_CONFIG_')) or key in ('RUSTC','RUSTDOC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTDOCFLAGS','CARGO_ENCODED_RUSTDOCFLAGS','CARGO_TARGET_DIR','CARGO_BUILD_TARGET','CARGO_BUILD_RUSTC','CARGO_BUILD_RUSTDOC','CARGO_BUILD_RUSTC_WRAPPER','CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER','PYTHONOPTIMIZE'):env.pop(key,None)
def save():(OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
def run(name,command):
 result=subprocess.run(list(map(str,command)),env=env,cwd=R,capture_output=True)
 row=dict(name=name,command=list(map(str,command)),exit_code=result.returncode)
 for field in ('stdout','stderr'):
  raw=getattr(result,field);(OUT/(name+'.'+field)).write_bytes(raw);row[field]=dict(path=name+'.'+field,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
 report['commands'].append(row);save()
 if result.returncode:raise RuntimeError(name+' failed: '+result.stderr.decode(errors='replace')[-4000:])
 print(name,'passed',flush=True);return result.stdout.decode()
save()
try:
 toolchain='1.89.0-aarch64-apple-darwin';paths={name:Path(run(name+'-path',['rustup','which','--toolchain',toolchain,name]).strip()) for name in ['rustc','cargo','rustdoc']}
 assert len({p.parent for p in paths.values()})==1
 env.update(RUSTUP_TOOLCHAIN=toolchain,RUSTC=str(paths['rustc']),RUSTDOC=str(paths['rustdoc']),CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='4',PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1')
 env['PATH']=os.pathsep.join([str(paths['rustc'].parent),str(nu.parent),str(Path(sys.executable).parent),env['PATH']])
 for name,flag in [('rustc','-vV'),('cargo','-Vv'),('rustdoc','-vV')]:
  observed=run(name+'-version',[paths[name],flag]);assert observed.startswith(name+' 1.89.0 ')
  if name=='rustc':assert 'host: aarch64-apple-darwin\n' in observed
 assert run('nu-version',[nu,'--version']).strip()=='0.112.2'
 run('vendor',[nu,'--no-config-file',R/'trisha/patches/apply.nu'])
 closures={};all_repos=set()
 for name in ['trisha','joy']:
  metadata=json.loads(run(name+'-metadata',[paths['cargo'],'metadata','--manifest-path',R/name/'Cargo.toml','--format-version','1','--all-features','--locked']))
  packages=[]
  for package in metadata['packages']:
   if package['source'] is None:
    manifest=Path(package['manifest_path']).resolve();relative=manifest.relative_to(R);repo=relative.parts[0];all_repos.add(repo);packages.append(dict(name=package['name'],manifest=str(relative),repository=repo))
  closures[name]=dict(repositories=sorted({p['repository'] for p in packages}),packages=packages)
 expected={row['repository'] for row in spec['sources']};assert all_repos==expected and len(all_repos)==11
 for row in spec['sources']:
  assert run(row['repository']+'-head',['git','-C',R/row['repository'],'rev-parse','HEAD']).strip()==row['commit']
  assert not run(row['repository']+'-status',['git','-C',R/row['repository'],'status','--porcelain=v1','--untracked-files=all']).strip()
 report.update(status='passed',production_repositories=sorted(all_repos),closures=closures,source_pins={r['repository']:r['commit'] for r in spec['sources']})
except BaseException:
 report.update(status='failed',error=traceback.format_exc());raise
finally:save()
