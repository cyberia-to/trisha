from pathlib import Path
import datetime,hashlib,json,re,subprocess,traceback
F=Path('/Users/master/cyber/.worktrees/selfhost-0.4-finalization-20261002')
ROOT=F/'current-distribution';CI=ROOT/'trisha-native-ci';OUT=ROOT/'measurements/origin-before-preparation';OUT.mkdir()
spec=json.loads((CI/'.github/current-package-inputs.json').read_text());report=dict(scope='Current-production feature-branch rehearsal source preparation; no export/upload/build',started=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='running',selector_sha256=hashlib.sha256((CI/'.github/current-package-inputs.json').read_bytes()).hexdigest(),commands=[],sources=[])
def save():(OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
def run(name,command):
 result=subprocess.run(list(map(str,command)),capture_output=True)
 row=dict(name=name,command=list(map(str,command)),exit_code=result.returncode)
 for field in ('stdout','stderr'):
  raw=getattr(result,field);path=OUT/(name+'.'+field);path.write_bytes(raw);row[field]=dict(path=path.name,sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
 report['commands'].append(row);save()
 if result.returncode:raise RuntimeError(name+' failed: '+result.stderr.decode(errors='replace')[-4000:])
 return result.stdout.decode()
save()
try:
 for selected in spec['sources']:
  name,pin=selected['repository'],selected['commit'];assert re.fullmatch('[a-z]+',name) and re.fullmatch('[0-9a-f]{40}',pin)
  refs={ref:sha for sha,ref in (line.split('\t') for line in run(name+'-refs',['git','ls-remote','--heads','https://github.com/cyberia-to/'+name+'.git']).splitlines())}
  head=refs[selected['origin_ref']]
  repo=json.loads(run(name+'-repository',['gh','api','repos/cyberia-to/'+name]));default=repo['default_branch'];assert 'refs/heads/'+default in refs
  compare=json.loads(run(name+'-reachability',['gh','api','repos/cyberia-to/'+name+'/compare/'+pin+'...'+head]));assert compare['merge_base_commit']['sha']==pin and compare['status'] in ('identical','ahead')
  source=F/'distribution'/name;destination=ROOT/name;assert not destination.exists()
  run(name+'-worktree',['git','-C',source,'worktree','add','--detach',destination,pin])
  assert run(name+'-head',['git','-C',destination,'rev-parse','HEAD']).strip()==pin
  assert not run(name+'-status',['git','-C',destination,'status','--porcelain=v1','--untracked-files=all']).strip()
  report['sources'].append(dict(repository=name,commit=pin,origin_ref=selected['origin_ref'],origin_head=head,default_branch=default,default_head=refs['refs/heads/'+default],reachability=compare['status'],worktree=str(destination)));save();print(name,pin,compare['status'],flush=True)
 report['status']='passed'
except BaseException:
 report.update(status='failed',error=traceback.format_exc());raise
finally:
 report['ended']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
