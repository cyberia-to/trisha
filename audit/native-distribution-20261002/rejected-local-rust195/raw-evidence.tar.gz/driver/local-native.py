"""Execute the committed native bootstrap on the actual Mac ARM host."""
from pathlib import Path
import datetime,hashlib,json,os,shutil,signal,subprocess,time
ROOT=Path(__file__).resolve().parent.parent
CHECKOUT=ROOT/'trisha-native-ci'
WORK=ROOT/'local-macos'
WORK.mkdir();(WORK/'.github').mkdir();(WORK/'scripts').mkdir();(WORK/'temporary').mkdir()
selector=json.loads((ROOT/'measurements/local-selector.json').read_text())
selector['full_baselines']=True
selector['targets']=['aarch64-apple-darwin']
(WORK/'.github/release-candidate.json').write_text(json.dumps(selector,indent=2)+'\n')
shutil.copyfile(CHECKOUT/'scripts/native-candidate.py',WORK/'scripts/native-candidate.py')
shutil.copyfile(ROOT/'measurements/local-transport.py',WORK/'local-transport.py')
env=dict(os.environ,RELEASE_TARGET='aarch64-apple-darwin',RUNNER_TEMP=str(WORK/'temporary'),PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1')
for key in ('RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_TARGET','CARGO_TARGET_DIR','TRIDENT_STDLIB','TRIDENT_OSLIB','TRIDENT_EXTLIB','TRIDENT_TARGET_PACKAGES','PYTHONOPTIMIZE'):env.pop(key,None)
env['GITHUB_SHA']=subprocess.check_output(['git','-C',str(CHECKOUT),'rev-parse','HEAD'],text=True).strip()
def identity(path):
 with path.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(bytes=path.stat().st_size,sha256=digest)
report=dict(schema='local/native-distribution-macos/v1',scope='Actual native Mac ARM feature-branch rehearsal; no default-branch release/tag/publication',started=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='running',bootstrap_revision=env['GITHUB_SHA'],bootstrap=identity(WORK/'scripts/native-candidate.py'),selector=selector,command=['python3','-B','local-transport.py'],transport_adapter=identity(WORK/'local-transport.py'),cwd=str(WORK),peak_process_group_rss_bytes=0,resource_guard_bytes=32*1024**3)
def save():(WORK/'driver.json').write_text(json.dumps(report,indent=2)+'\n')
save();started=time.monotonic();stopped=False
with (WORK/'driver.stdout').open('xb') as out,(WORK/'driver.stderr').open('xb') as err,(WORK/'resources.jsonl').open('x') as resources:
 child=subprocess.Popen(report['command'],cwd=WORK,env=env,stdout=out,stderr=err,start_new_session=True)
 report['pid']=child.pid;save()
 while child.poll() is None:
  rows=subprocess.check_output(['/bin/ps','-axo','pid,pgid,rss'],text=True).splitlines()[1:]
  rss=sum(int(v[2])*1024 for line in rows if len(v:=line.split())==3 and int(v[1])==child.pid)
  report['peak_process_group_rss_bytes']=max(report['peak_process_group_rss_bytes'],rss)
  resources.write(json.dumps(dict(elapsed_seconds=time.monotonic()-started,rss_bytes=rss,peak_rss_bytes=report['peak_process_group_rss_bytes']))+'\n');resources.flush();save()
  if rss>report['resource_guard_bytes']:
   stopped=True;os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   break
  time.sleep(5)
 report.update(exit_code=child.wait(),resource_stopped=stopped)
report.update(status='passed' if report['exit_code']==0 and not stopped else 'failed',ended=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-started)
for name in ('driver.stdout','driver.stderr','resources.jsonl'):report[name]=identity(WORK/name)
save();print(json.dumps({k:report[k] for k in ('status','exit_code','peak_process_group_rss_bytes','elapsed_seconds')},indent=2),flush=True)
raise SystemExit(report['exit_code'] or int(stopped))
