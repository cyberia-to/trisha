"""Execute archived installed-candidate gates serially, retaining every outcome."""
from pathlib import Path
import datetime,hashlib,json,os,re,signal,subprocess,tarfile,time
OUT=Path(__file__).resolve().parent
SOURCE=OUT/'unpacked/cyber-source'
CANDIDATE=OUT/'candidate пробел'
SCRIPTS=SOURCE/'trisha/scripts'
SMOKE=OUT/'smoke пробел'
RESULTS=OUT/'installed-results'
PREPARE=json.loads((OUT/'prepare.json').read_text())
BUILD=json.loads((OUT/'build.json').read_text())
def sha(path):
 digest=hashlib.sha256()
 with path.open('rb') as stream:
  for block in iter(lambda:stream.read(1<<20),b''):digest.update(block)
 return digest.hexdigest()
def identity(path):return dict(bytes=path.stat().st_size,sha256=sha(path))
def require(value,message):
 if not value:raise ValueError(message)
require(BUILD['status']=='passed','completed build required')
RESULTS.mkdir();(OUT/'temporary').mkdir()
env=dict(os.environ)
for name in ('RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_TARGET','CARGO_TARGET_DIR','TRIDENT_STDLIB','TRIDENT_OSLIB','TRIDENT_EXTLIB','TRIDENT_TARGET_PACKAGES','PYTHONOPTIMIZE'):env.pop(name,None)
env.update(PREPARE['environment'])
env['PATH']=str(CANDIDATE/'bin')+os.pathsep+env['PATH']
env['TMPDIR']=str(OUT/'temporary')
report=dict(schema='local/coordinated-soft3-installed/v1',status='running',scope='One local feature-branch candidate; no six-platform, SH6, live deployment or release acceptance',started=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver=identity(Path(__file__)),prepare=identity(OUT/'prepare.json'),build=identity(OUT/'build.json'),candidate_start=identity(CANDIDATE/'candidate.json'),commands=[],environment={key:env[key] for key in (*PREPARE['environment'],'TMPDIR')})
candidate=json.loads((CANDIDATE/'candidate.json').read_text())
report['binary_start']={row['name']:identity(CANDIDATE/'bin'/row['name']) for row in candidate['binaries']}
require({k:v['sha256'] for k,v in report['binary_start'].items()}=={r['name']:r['sha256'] for r in candidate['binaries']},'candidate binaries')
def flush():(OUT/'smoke.json').write_text(json.dumps(report,indent=2)+'\n')
def run(name,argv,timeout=1800):
 row=dict(name=name,argv=list(map(str,argv)),cwd=str(OUT),timeout_seconds=timeout,status='running',exit_code=None)
 report['commands'].append(row);flush();start=time.monotonic_ns()
 try:
  with (RESULTS/(name+'.stdout')).open('xb') as stdout,(RESULTS/(name+'.stderr')).open('xb') as stderr:
   child=subprocess.Popen(row['argv'],cwd=OUT,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
   try:code=child.wait(timeout=timeout)
   except subprocess.TimeoutExpired:
    os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
    row['status']='timeout';raise
  row.update(status='completed',exit_code=code)
 finally:
  row['elapsed_ns']=time.monotonic_ns()-start
  for stream in ('stdout','stderr'):
   path=RESULTS/(name+'.'+stream)
   if path.is_file():row[stream]=dict(path=str(path.relative_to(OUT)),**identity(path))
  flush()
 print(name,code,flush=True)
 require(code==0,f'{name} exited {code}')
 return (RESULTS/(name+'.stdout')).read_text()
flush()
try:
 run('source-before',['python3','-B',SCRIPTS/'verify-source.py',SOURCE,'--expect',CANDIDATE/'source-verification.json'])
 run('joy-native',['python3','-B',SOURCE/'joy/scripts/smoke-native.py','--joy',CANDIDATE/'bin/joy','--fixtures',CANDIDATE/'share/trisha-release-smoke','--output',OUT/'joy-native-smoke'],1800)
 run('full-smoke',['nu','--no-config-file',SCRIPTS/'smoke-release.nu',CANDIDATE/'bin',SMOKE],10800)
 run('corpus-seal',['python3','-B',SCRIPTS/'verify-corpus.py',SMOKE,'--seal'])
 run('corpus-local',['python3','-B',SCRIPTS/'verify-corpus.py',SMOKE,'--candidate',CANDIDATE,'--receipt',RESULTS/'local-corpus-verification.json'])
 run('native-process-files',['python3','-B',SOURCE/'trisha/audit/native-installed-probes.py',CANDIDATE,RESULTS/'native-process-files.json'])
 execution=run('baseline-execution',[CANDIDATE/'bin/trisha','bench',SOURCE/'trisha/baselines/triton']).splitlines()
 require(execution.count('133 / 133 fixtures passed; 43 / 43 baselines verified')==1 and sum(line.endswith('\tPASS') for line in execution)==99 and sum(line.endswith('\tPASS (both executions rejected)') for line in execution)==34,'native baseline coverage')
 report['baseline_execution']=dict(fixtures=133,baselines=43,positive=99,negative=34,generated_proofs=0)
 first=OUT/'cyber-tools-aarch64-apple-darwin.tar.gz'; second=OUT/'repacked.tar.gz'
 for label,path in [('package',first),('repack',second)]:run(label,['nu','--no-config-file',SCRIPTS/'package-binaries.nu',CANDIDATE,path,'--smoke',SMOKE/'smoke.json'])
 require(identity(first)==identity(second),'deterministic binary archive identity')
 report['binary_archive']=identity(first)
 installed=OUT/'installed';installed.mkdir()
 with tarfile.open(first) as content:content.extractall(installed,filter='data')
 prefix=installed/'cyber-tools'
 require({row['name']:identity(prefix/'bin'/row['name']) for row in candidate['binaries']}==report['binary_start'],'unpacked binaries')
 run('unpacked-lsp',['python3','-B',SCRIPTS/'smoke-lsp.py',prefix/'bin/trident-lsp'])
 run('corpus-package',['python3','-B',SCRIPTS/'archive-source.py',SMOKE,OUT/'proof-corpus-aarch64-apple-darwin.tar.gz','--prefix','proof-corpus','--epoch','0'])
 report['proof_corpus_archive']=identity(OUT/'proof-corpus-aarch64-apple-darwin.tar.gz')
 report['status']='passed'
except BaseException as error:report.update(status='failed',error=f'{type(error).__name__}: {error}')
finally:
 try:
  run('source-after',['python3','-B',SCRIPTS/'verify-source.py',SOURCE,'--expect',CANDIDATE/'source-verification.json'])
  report['candidate_end']=identity(CANDIDATE/'candidate.json')
  report['binary_end']={row['name']:identity(CANDIDATE/'bin'/row['name']) for row in candidate['binaries']}
  require(report['candidate_start']==report['candidate_end'] and report['binary_start']==report['binary_end'],'candidate changed')
 except BaseException as error:report.update(status='failed',finalization_error=f'{type(error).__name__}: {error}')
 report['ended']=datetime.datetime.now(datetime.timezone.utc).isoformat();flush()
raise SystemExit(0 if report['status']=='passed' else 1)
