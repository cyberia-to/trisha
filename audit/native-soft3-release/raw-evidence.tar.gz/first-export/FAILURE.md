# Coordinated local candidate rehearsal: fixture lock rejection

The strict source export passed, but the Rust 1.89.0 candidate build failed
before publication. The archived fixture helper command rejected its frozen
`trisha/scripts/fixtures/Cargo.lock` because an update is required while
`--locked` is set. No lock, source, dependency or toolchain was changed in
response. The installed smoke, corpus and package gates have not run.

`prepare.json` records the exact eleven committed, clean input revisions,
resolved tool paths and versions, source archive SHA-256 and successful source
verification after extraction. The source archive is `source-export.tar.gz`,
113,613,446 bytes, SHA-256
`e62c62421fe3ab93d69722891cf187c83568ef074cade921b8eda0f3de9af30f`.
This is a local feature-branch rehearsal, not a candidate cut from default
branches, publication, SH6 result or six-platform verdict.

`build.json` binds the archived build script invocation, environment, logs and
before/after source guards. Cargo and rustc were the actual rustup-managed
1.89.0 tools, with the rustup shims first on PATH. Cargo build jobs and Rayon
threads were both four; `TVM_LDE_TRACE=no_cache`. The archive's script advanced
through the Trident, Trisha and Joy build stages before invoking the fixture
helper. The error was a locked-dependency guard, with no observed Rust language
or MSRV diagnostic. This does not establish all 1.89 gates, because the complete
build and subsequent tests remain unfinished.

The archived build script deletes its private candidate staging directory on
failure. Therefore no candidate or per-project staging logs survived; the
unaltered outer stdout/stderr and exact error are retained. No installed binary
identity is claimed for this failed attempt. The source guard still passed
afterward, and the original archive is retained unchanged.

`smoke.py` is an unexecuted local driver prepared for the dependent gates. Its
presence is not a receipt or acceptance result. Any corrected source family
must be exported and built into fresh paths; this failed evidence remains.
