from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,time
OUT=Path(__file__).resolve().parent
SOURCE=OUT/'unpacked/cyber-source'
CANDIDATE=OUT/'candidate пробел'
PREPARE=json.loads((OUT/'prepare.json').read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
env=dict(os.environ)
for n in ('RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_TARGET','CARGO_TARGET_DIR','TRIDENT_STDLIB','TRIDENT_OSLIB','TRIDENT_EXTLIB','TRIDENT_TARGET_PACKAGES','PYTHONOPTIMIZE'):env.pop(n,None)
env.update(PREPARE['environment'])
report=dict(schema='local/coordinated-soft3-build/v1',status='running',started=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)),prepare_sha256=sha(OUT/'prepare.json'),source_archive=PREPARE['source_archive'],source=str(SOURCE),candidate=str(CANDIDATE),environment=PREPARE['environment'],commands=[])
def flush(): (OUT/'build.json').write_text(json.dumps(report,indent=2)+'\n')
def run(name,argv,timeout):
 row=dict(name=name,argv=list(map(str,argv)),cwd=str(OUT),status='running',exit_code=None);report['commands'].append(row);flush();start=time.monotonic_ns()
 try:
  with (OUT/(name+'.stdout')).open('xb') as stdout,(OUT/(name+'.stderr')).open('xb') as stderr:
   result=subprocess.run(row['argv'],cwd=OUT,env=env,stdout=stdout,stderr=stderr,timeout=timeout)
  row.update(status='completed',exit_code=result.returncode)
 finally:
  row['elapsed_ns']=time.monotonic_ns()-start
  for stream in ('stdout','stderr'):
   p=OUT/(name+'.'+stream)
   if p.is_file():row[stream]=dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p))
  flush()
 print(name,result.returncode,flush=True)
 if result.returncode:raise RuntimeError(f'{name} exited {result.returncode}')
flush()
try:
 if PREPARE['status']!='passed' or CANDIDATE.exists():raise ValueError('passed preparation and fresh candidate required')
 run('build-source-before',['python3','-B',SOURCE/'trisha/scripts/verify-source.py',SOURCE,'--expect',OUT/'source-guard.stdout'],1800)
 run('candidate-build',['/Users/master/.cargo/bin/rustup','run','1.89.0','nu','--no-config-file',SOURCE/'trisha/scripts/build-candidate.nu',SOURCE,CANDIDATE],10800)
 report['candidate_identity']=dict(bytes=(CANDIDATE/'candidate.json').stat().st_size,sha256=sha(CANDIDATE/'candidate.json'))
 report['candidate_record']=json.loads((CANDIDATE/'candidate.json').read_text())
 report['status']='passed'
except BaseException as e:report.update(status='failed',error=f'{type(e).__name__}: {e}')
finally:
 try:run('build-source-after',['python3','-B',SOURCE/'trisha/scripts/verify-source.py',SOURCE,'--expect',OUT/'source-guard.stdout'],1800)
 except BaseException as e:report.update(status='failed',source_guard_error=f'{type(e).__name__}: {e}')
 report['candidate_published']=CANDIDATE.exists()
 report['remaining_staging']=sorted(p.name for p in OUT.glob('candidate пробел.building.*'))
 report['ended']=datetime.datetime.now(datetime.timezone.utc).isoformat();flush()
raise SystemExit(0 if report['status']=='passed' else 1)
