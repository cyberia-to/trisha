from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,tarfile,time

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
FAMILY=ROOT/'portable-native-smoke'
RUSTUP=Path('/Users/master/.cargo/bin/rustup')
NAMES=('bbg','hemera','honeycrisp','joy','lens','neuron','nox','strata','trident','trisha','zheng')

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()

def sources():
 return {n:dict(revision=subprocess.check_output(['git','-C',str(FAMILY/n),'rev-parse','HEAD'],text=True).strip(),status=subprocess.check_output(['git','-C',str(FAMILY/n),'status','--porcelain','--untracked-files=all'],text=True)) for n in NAMES}

env=dict(os.environ,RUSTUP_TOOLCHAIN='1.89.0',CARGO_BUILD_JOBS='4',RAYON_NUM_THREADS='4',TVM_LDE_TRACE='no_cache',PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1')
for n in ('RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_TARGET','CARGO_TARGET_DIR','TRIDENT_STDLIB','TRIDENT_OSLIB','TRIDENT_EXTLIB','TRIDENT_TARGET_PACKAGES','PYTHONOPTIMIZE'):env.pop(n,None)
env['PATH']=str(RUSTUP.parent)+os.pathsep+env['PATH']
report=dict(schema='local/coordinated-soft3-rehearsal-prepare/v1',status='running',scope='Strict committed local feature-branch family; not an origin/default-branch release candidate or SH6/platform verdict',started=datetime.datetime.now(datetime.timezone.utc).isoformat(),before=sources(),commands=[],environment={k:env[k] for k in ('RUSTUP_TOOLCHAIN','PATH','CARGO_BUILD_JOBS','RAYON_NUM_THREADS','TVM_LDE_TRACE','PYTHONDONTWRITEBYTECODE','PYTHONUTF8')},driver_sha256=sha(Path(__file__)))
def flush(): (OUT/'prepare.json').write_text(json.dumps(report,indent=2)+'\n')
def run(name,argv,cwd=FAMILY/'trisha',timeout=1800):
 row=dict(name=name,argv=list(map(str,argv)),cwd=str(cwd),status='running');report['commands'].append(row);flush()
 start=time.monotonic_ns()
 with (OUT/(name+'.stdout')).open('xb') as out,(OUT/(name+'.stderr')).open('xb') as err:
  result=subprocess.run(row['argv'],cwd=cwd,env=env,stdout=out,stderr=err,timeout=timeout)
 row.update(status='completed',exit_code=result.returncode,elapsed_ns=time.monotonic_ns()-start)
 for stream in ('stdout','stderr'):
  p=OUT/(name+'.'+stream);row[stream]=dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p))
 flush();print(name,result.returncode,flush=True)
 if result.returncode:raise RuntimeError(f'{name} exited {result.returncode}')
 return (OUT/(name+'.stdout')).read_text()
flush()
try:
 if any(v['status'] for v in report['before'].values()):raise ValueError('eleven clean source trees required')
 for name,argv in [('rustc-version',[RUSTUP,'run','1.89.0','rustc','-vV']),('cargo-version',[RUSTUP,'run','1.89.0','cargo','-V']),('nu-version',['nu','--version']),('python-version',['python3','--version'])]:run(name,argv)
 report['tool_paths']={n:dict(invoked=shutil.which(n,path=env['PATH']),resolved=str(Path(shutil.which(n,path=env['PATH'])).resolve())) for n in ('cargo','rustc','nu','python3','rustup')}
 for n in ('rustc','cargo'):
  path=Path(run(n+'-absolute',[RUSTUP,'which','--toolchain','1.89.0',n]).strip())
  report['tool_paths'][n].update(actual_toolchain=str(path),sha256=sha(path))
 run('package-source',[RUSTUP,'run','1.89.0','nu',FAMILY/'trisha/scripts/package-source.nu',OUT/'source-export'])
 archive=OUT/'source-export.tar.gz'
 report['source_archive']=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive))
 manifest=json.loads((OUT/'source-export/sources.json').read_text())
 report['exported_pins']={row['repository']:row['commit'] for row in manifest}
 if report['exported_pins']!={n:v['revision'] for n,v in report['before'].items()}:raise ValueError('exported source pins mismatch')
 unpacked=OUT/'unpacked';unpacked.mkdir()
 with tarfile.open(archive) as content:content.extractall(unpacked,filter='data')
 source=unpacked/'cyber-source'
 run('source-guard',['python3','-B',source/'trisha/scripts/verify-source.py',source])
 report['sources_json']=dict(sha256=sha(source/'sources.json'),bytes=(source/'sources.json').stat().st_size)
 report['after']=sources()
 if report['before']!=report['after']:raise ValueError('source checkouts changed during strict packaging')
 report['status']='passed'
except BaseException as e:report.update(status='failed',error=f'{type(e).__name__}: {e}')
finally:
 report['ended']=datetime.datetime.now(datetime.timezone.utc).isoformat();flush()
raise SystemExit(0 if report['status']=='passed' else 1)
