"""Run the archived native coordinator's CPU tests, then its separate proof gate."""
from pathlib import Path
import datetime,hashlib,json,os,re,signal,subprocess,time
ROOT=Path(__file__).resolve().parent;SOURCE=ROOT/'unpacked/cyber-source';CANDIDATE=ROOT/'candidate пробел';RESULTS=ROOT/'cpu-results'
prepare=json.loads((ROOT/'prepare.json').read_text());smoke=json.loads((ROOT/'smoke.json').read_text());z3=json.loads((ROOT/'tools/z3.json').read_text())
def require(ok,message):
 if not ok:raise ValueError(message)
def sha(path):
 digest=hashlib.sha256()
 with path.open('rb') as stream:
  for block in iter(lambda:stream.read(1<<20),b''):digest.update(block)
 return digest.hexdigest()
def identity(path):return dict(bytes=path.stat().st_size,sha256=sha(path))
require(smoke['status']=='passed' and z3['status']=='passed','complete installed gates and pinned real Z3 required')
RESULTS.mkdir();env=dict(os.environ)
for name in ('RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_TARGET','CARGO_TARGET_DIR','TRIDENT_STDLIB','TRIDENT_OSLIB','TRIDENT_EXTLIB','TRIDENT_TARGET_PACKAGES','PYTHONOPTIMIZE'):env.pop(name,None)
env.update(prepare['environment']);env['PATH']=os.pathsep.join([str(Path(z3['binary']['path']).parent),str(CANDIDATE/'bin'),env['PATH']]);env['TMPDIR']=str(ROOT/'temporary')
candidate=json.loads((CANDIDATE/'candidate.json').read_text());env['RUSTFLAGS']=candidate['rustflags']
names=('trident','trident-lsp','trisha','joy')
report=dict(schema='local/coordinated-native-cpu-and-proofs/v1',status='running',scope='One actual macOS ARM local feature-branch archived candidate; no six-platform or release verdict',started=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver=identity(Path(__file__)),archived_coordinator=identity(SOURCE/'trisha/scripts/native-candidate.py'),prepare=identity(ROOT/'prepare.json'),installed_gates=identity(ROOT/'smoke.json'),z3_receipt=identity(ROOT/'tools/z3.json'),candidate_start=identity(CANDIDATE/'candidate.json'),binaries_start={n:identity(CANDIDATE/'bin'/n) for n in names},environment={k:env[k] for k in (*prepare['environment'],'TMPDIR','RUSTFLAGS')},commands=[],cpu_failures=[])
def flush():(ROOT/'cpu-and-proofs.json').write_text(json.dumps(report,indent=2)+'\n')
def run(name,argv,timeout=10800,allow_failure=False):
 row=dict(name=name,argv=list(map(str,argv)),cwd=str(ROOT),status='running',exit_code=None,timeout_seconds=timeout,cargo_target_dir=env.get('CARGO_TARGET_DIR'));report['commands'].append(row);flush();start=time.monotonic_ns()
 try:
  with (RESULTS/(name+'.stdout')).open('xb') as stdout,(RESULTS/(name+'.stderr')).open('xb') as stderr:
   child=subprocess.Popen(row['argv'],cwd=ROOT,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
   try:code=child.wait(timeout=timeout)
   except subprocess.TimeoutExpired:
    os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
    row['status']='timeout';raise
  row.update(status='completed',exit_code=code)
 finally:
  row['elapsed_ns']=time.monotonic_ns()-start
  for stream in ('stdout','stderr'):
   path=RESULTS/(name+'.'+stream)
   if path.is_file():row[stream]=dict(path=str(path.relative_to(ROOT)),**identity(path))
  flush()
 data=(RESULTS/(name+'.stdout')).read_bytes()+(RESULTS/(name+'.stderr')).read_bytes()
 row['warning_lines']=len(re.findall(rb'^warning(?:\[[^\]\r\n]+\])?:',data,re.M))
 summaries=re.findall(rb'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',data)
 if summaries:row['rust_summaries']=len(summaries);row['rust_totals']=dict(zip(('passed','failed','ignored'),map(sum,zip(*(tuple(map(int,x[1:])) for x in summaries)))))
 flush();print(name,code,'warnings',row['warning_lines'],flush=True)
 if code or row['warning_lines']:
  if allow_failure:report['cpu_failures'].append(name);flush()
  else:raise ValueError(f'{name} failed')
flush()
try:
 run('source-before',['python3','-B',SOURCE/'trisha/scripts/verify-source.py',SOURCE,'--expect',CANDIDATE/'source-verification.json'])
 for name,argv in [('rustc',['rustc','-vV']),('cargo',['cargo','-V']),('z3',['z3','--version'])]:run(name,argv)
 require('release: 1.89.0\n' in (RESULTS/'rustc.stdout').read_text() and (RESULTS/'z3.stdout').read_text().startswith('Z3 version 4.15.3'),'actual pinned compiler and solver')
 for project in ('trident','trisha','joy'):
  env['CARGO_TARGET_DIR']=str(CANDIDATE/'build'/project)
  command=['cargo','test','--manifest-path',SOURCE/project/'Cargo.toml','--release','--locked','--no-fail-fast']
  if project=='trisha':
   for package in ('trisha','trisha-rs','trisha-neptune','trisha-honeycrisp'):command+=['-p',package]
  else:command+=['--workspace']
  run(project+'-tests',command+['--','--test-threads=1'],allow_failure=True)
 require(not report['cpu_failures'],'archived CPU test gates failed')
 report['cpu_status']='passed';flush()
 env.pop('CARGO_TARGET_DIR',None)
 run('baseline-proofs',['python3','-B',SOURCE/'trisha/scripts/check-baselines.py',CANDIDATE,ROOT/'baseline-proofs','--rss-limit-gib','28'],timeout=None)
 proof=json.loads((ROOT/'baseline-proofs/receipt.json').read_text())
 require(proof['all_checks_passed'] is True and proof['fresh_verified_proofs']==198,'complete native proof evidence')
 report['baseline_proofs_receipt']=identity(ROOT/'baseline-proofs/receipt.json');report['status']='passed'
except BaseException as error:report.update(status='failed',error=f'{type(error).__name__}: {error}')
finally:
 try:
  run('source-after',['python3','-B',SOURCE/'trisha/scripts/verify-source.py',SOURCE,'--expect',CANDIDATE/'source-verification.json'])
  report['candidate_end']=identity(CANDIDATE/'candidate.json');report['binaries_end']={n:identity(CANDIDATE/'bin'/n) for n in names}
  require(report['candidate_start']==report['candidate_end'] and report['binaries_start']==report['binaries_end'],'candidate inputs changed')
  require(identity(Path(z3['binary']['path']))=={k:z3['binary'][k] for k in ('bytes','sha256')},'pinned solver changed')
 except BaseException as error:report.update(status='failed',finalization_error=f'{type(error).__name__}: {error}')
 report['ended']=datetime.datetime.now(datetime.timezone.utc).isoformat();flush()
raise SystemExit(0 if report['status']=='passed' else 1)
