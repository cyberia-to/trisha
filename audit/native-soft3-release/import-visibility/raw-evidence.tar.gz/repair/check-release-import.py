from pathlib import Path
import hashlib,json,os,re,subprocess,time
r=Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap');repo=r/'portable-native-smoke/trisha';candidate=r/'measurements/coordinated-soft3-release-2/candidate пробел';out=r/'measurements/release-import-visibility';out.mkdir()
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
script=repo/'scripts/smoke-release.nu';before={p.name:h(p) for p in (candidate/'bin').iterdir() if p.is_file()}
text=script.read_text()
for name in ('release_helper.tri','imported-nox.tri','imported-triton.tri'):
 matches=re.findall(r'^    (".*") \| save '+re.escape(name)+r'$',text,re.M);assert len(matches)==1
 (out/name).write_text(json.loads(matches[0]))
helper=out/'release_helper.tri';public=helper.read_text();private=public.replace('pub a:Field,pub b:Field','a:Field,b:Field');assert private!=public
(out/'release_helper.public.tri').write_text(public);(out/'release_helper.private.tri').write_text(private)
env=os.environ.copy();env['PATH']=str(candidate/'bin')+os.pathsep+env['PATH']
for key in ('TRIDENT_STDLIB','TRIDENT_OSLIB','TRIDENT_EXTLIB','TRIDENT_TARGET_PACKAGES'):env.pop(key,None)
report={'schema':'local/release-import-visibility/v1','status':'running','trisha_parent':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'script_sha256':h(script),'candidate':{'path':str(candidate),'manifest_sha256':h(candidate/'candidate.json'),'binaries':before},'driver_sha256':h(Path(__file__)),'commands':[]}
try:
 for profile in ('debug','release'):
  for inputs,expected in [('3,5','803'),('4,5','809')]:
   for name,source,target in [('trident','imported-nox.tri','nox'),('joy','imported-nox.tri','nox'),('trident','imported-triton.tri','triton'),('trisha','imported-triton.tri','triton')]:
    command=[str(candidate/'bin'/name),'run',source,'--target',target,'--profile',profile,'--input-values',inputs]
    p=subprocess.run(command,cwd=out,env=env,capture_output=True,timeout=120);i=len(report['commands']);(out/f'{i}.stdout').write_bytes(p.stdout);(out/f'{i}.stderr').write_bytes(p.stderr)
    report['commands'].append({'argv':command,'exit_code':p.returncode,'expected_output':expected,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()})
    assert p.returncode==0 and p.stdout.decode().strip()==expected,report['commands'][-1]
 helper.write_text(private)
 for target,source in [('nox','imported-nox.tri'),('triton','imported-triton.tri')]:
  command=[str(candidate/'bin/trident'),'check',source,'--target',target]
  p=subprocess.run(command,cwd=out,env=env,capture_output=True,timeout=120);i=len(report['commands']);(out/f'{i}.stdout').write_bytes(p.stdout);(out/f'{i}.stderr').write_bytes(p.stderr)
  report['commands'].append({'argv':command,'exit_code':p.returncode,'expected_error':'private fields','stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()})
  assert p.returncode==1 and b'is private' in p.stderr,report['commands'][-1]
 assert before=={p.name:h(p) for p in (candidate/'bin').iterdir() if p.is_file()}
 assert report['script_sha256']==h(script)
 report.update(status='passed',positive_commands=16,private_rejections=2)
except BaseException as error:
 report.update(status='failed',error=f'{type(error).__name__}: {error}');raise
finally:
 helper.write_text(public)
 (out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'positive_commands':16,'private_rejections':2}))
