# Second local rehearsal: stale private-field fixture

The corrected strict source export and complete candidate build passed under
Rust 1.89.0. The four build logs have zero warnings, the fixture helper completed,
and the before/after source guards passed. Exact sources, commands, tools and
binary identities are retained in prepare.json, build.json and the local
candidate's candidate.json. This remains a feature-branch local rehearsal.

The installed Joy-owned smoke passed all49 commands. The full archived smoke
then exited1 at its imported-nox case: release_helper.Pair declares a public
struct but private a/b fields, and imported-nox accesses those fields from a
different module. The runtime correctly rejected the access. No archived source
or partial smoke output was repaired. Prior recursive outer-proof, typed-entry,
RAM and Joy public/private/state checks completed before this later case; the
complete suite is still failed and no smoke.json acceptance file was published.

smoke.json is the local orchestration receipt; installed-results/full-smoke.*
contains the actual failure. partial-smoke-files.json binds the exact retained
unsealed partial tree. The source guard and all four binary start/end hashes
remained unchanged. Corpus sealing/consumption and binary packaging were not
run because the complete smoke did not pass.

Independent commands then passed28 native process/file probes and all133
execution fixtures (99positive,34rejection) covering43 baselines. The process
probes use their explicit local Neptune fixture, not a live node or wallet.
No baseline proof generation was requested. independent.json records an
additional local wrapper mistake: it searched only stdout for the benchmark
summary, which the CLI prints to stderr. All actual commands exited0. The
unchanged archived coordinator combines the streams and has no such issue.
check-independent.py performed a separate read-only validation of both retained
streams, all133 rows and original source/binary bindings; its passed result is
independent-validation.json. The first wrapper receipt remains failed and
unchanged. None of these supplemental checks upgrades the failed full smoke.

The original first attempt is separate in coordinated-soft3-release. A third
attempt must use a newly committed fixture and fresh source/candidate/smoke
paths. No release, SH6, six-platform or SH7/SH8 acceptance is claimed here.
