"""Validate the preserved split streams; no commands or original receipts rerun."""
from pathlib import Path
import hashlib,json,time
ROOT=Path(__file__).resolve().parent

def require(ok,message):
 if not ok:raise ValueError(message)
def identity(path):
 data=path.read_bytes();return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
report=json.loads((ROOT/'independent.json').read_text())
require(report['status']=='failed' and report['error']=='ValueError: exact133fixturecoverage','expected preserved local guard failure')
require([c['name'] for c in report['commands']]==['source-before','native-process-files','baseline-execution','source-after'],'complete independent sequence')
for command in report['commands']:
 require(command['status']=='completed' and command['exit_code']==0,'actual commands exited zero')
 for stream in ('stdout','stderr'):
  item=command[stream]
  require(identity(ROOT/item['path'])=={k:item[k] for k in ('bytes','sha256')},'raw command log binding')
require(report['binaries_before']==report['binaries_after'],'original before/after binary binding')
candidate=ROOT/'candidate пробел'
require({n:identity(candidate/'bin'/n) for n in report['binaries_before']}==report['binaries_before'],'binary still unchanged')
logroot=ROOT/'independent-results'
stdout=(logroot/'baseline-execution.stdout').read_text().splitlines();stderr=(logroot/'baseline-execution.stderr').read_text().splitlines()
require((stdout+stderr).count('133 / 133 fixtures passed; 43 / 43 baselines verified')==1,'complete baseline summary across both streams')
positive=[line for line in stdout if line.endswith('\tPASS')];negative=[line for line in stdout if line.endswith('\tPASS (both executions rejected)')]
require(len(positive)==99 and len(negative)==34 and len(set(line.split('\t')[0] for line in positive+negative))==133,'exact independent rows')
require((logroot/'source-before.stdout').read_bytes()==(logroot/'source-after.stdout').read_bytes(),'source guard unchanged')
probes=json.loads((logroot/'native-process-files.json').read_text())
require(probes['all_checks_passed'] is True and len(probes['checks'])==28,'actual native process cases')
require(probes['binaries']=={n:v['sha256'] for n,v in report['binaries_before'].items()},'probe binary binding')
result=dict(schema='local/coordinated-independent-log-validation/v1',status='passed',scope='Read-only validation of completed native process/file and execution commands; failed full smoke and original local guard result unchanged',time_ns=time.time_ns(),checker=identity(Path(__file__)),original_failed_driver_receipt=identity(ROOT/'independent.json'),native_probes=identity(logroot/'native-process-files.json'),native_probe_count=28,baseline_log_stdout=identity(logroot/'baseline-execution.stdout'),baseline_log_stderr=identity(logroot/'baseline-execution.stderr'),baseline_execution=dict(fixtures=133,baselines=43,positive=99,negative=34,generated_proofs=0),explanation='Original wrapper mistakenly required the summary in stdout alone; archived coordinator combines streams and remains correct.')
with (ROOT/'independent-validation.json').open('x') as output:output.write(json.dumps(result,indent=2)+'\n')
print('PASS:28 native process/file checks;133 executions,43 baselines; split-stream guard corrected by read-only validation')
