"""Independent execution/process gates after a failed installed proof smoke."""
from pathlib import Path
import hashlib,json,os,subprocess,time
OUT=Path(__file__).resolve().parent;SOURCE=OUT/'unpacked/cyber-source';CANDIDATE=OUT/'candidate пробел';RESULTS=OUT/'independent-results';RESULTS.mkdir()
prepare=json.loads((OUT/'prepare.json').read_text());build=json.loads((OUT/'build.json').read_text())
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  for block in iter(lambda:stream.read(1<<20),b''):h.update(block)
 return h.hexdigest()
def identity(path):return dict(bytes=path.stat().st_size,sha256=sha(path))
def require(ok,message):
 if not ok:raise ValueError(message)
env=dict(os.environ)
for name in ('RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_TARGET','CARGO_TARGET_DIR','TRIDENT_STDLIB','TRIDENT_OSLIB','TRIDENT_EXTLIB','TRIDENT_TARGET_PACKAGES','PYTHONOPTIMIZE'):env.pop(name,None)
env.update(prepare['environment']);env['PATH']=str(CANDIDATE/'bin')+os.pathsep+env['PATH'];env['TMPDIR']=str(OUT/'temporary')
names=('trident','trident-lsp','trisha','joy');before={n:identity(CANDIDATE/'bin'/n) for n in names}
report=dict(schema='local/coordinated-independent-execution/v1',status='running',scope='Independent process/file and execution checks only; full installed smoke remains failed, no corpus/package/release acceptance',driver=identity(Path(__file__)),build=identity(OUT/'build.json'),failed_smoke=identity(OUT/'smoke.json'),binaries_before=before,commands=[],started_ns=time.time_ns())
def flush():(OUT/'independent.json').write_text(json.dumps(report,indent=2)+'\n')
def run(name,argv):
 row=dict(name=name,argv=list(map(str,argv)),cwd=str(OUT),status='running',exit_code=None);report['commands'].append(row);flush();start=time.monotonic_ns()
 with (RESULTS/(name+'.stdout')).open('xb') as stdout,(RESULTS/(name+'.stderr')).open('xb') as stderr:
  result=subprocess.run(row['argv'],cwd=OUT,env=env,stdout=stdout,stderr=stderr,timeout=1800)
 row.update(status='completed',exit_code=result.returncode,elapsed_ns=time.monotonic_ns()-start)
 for stream in ('stdout','stderr'):row[stream]=dict(path=str((RESULTS/(name+'.'+stream)).relative_to(OUT)),**identity(RESULTS/(name+'.'+stream)))
 flush();print(name,result.returncode,flush=True);require(result.returncode==0,f'{name} exited {result.returncode}')
 return (RESULTS/(name+'.stdout')).read_text()
flush()
try:
 require(build['status']=='passed','candidate build passed')
 run('source-before',['python3','-B',SOURCE/'trisha/scripts/verify-source.py',SOURCE,'--expect',CANDIDATE/'source-verification.json'])
 run('native-process-files',['python3','-B',SOURCE/'trisha/audit/native-installed-probes.py',CANDIDATE,RESULTS/'native-process-files.json'])
 lines=run('baseline-execution',[CANDIDATE/'bin/trisha','bench',SOURCE/'trisha/baselines/triton']).splitlines()
 require(lines.count('133 / 133 fixtures passed; 43 / 43 baselines verified')==1 and sum(x.endswith('\tPASS') for x in lines)==99 and sum(x.endswith('\tPASS (both executions rejected)') for x in lines)==34,'exact133fixturecoverage')
 report['baseline_execution']=dict(fixtures=133,baselines=43,positive=99,negative=34,generated_proofs=0)
 report['status']='passed'
except BaseException as e:report.update(status='failed',error=f'{type(e).__name__}: {e}')
finally:
 try:
  run('source-after',['python3','-B',SOURCE/'trisha/scripts/verify-source.py',SOURCE,'--expect',CANDIDATE/'source-verification.json'])
  report['binaries_after']={n:identity(CANDIDATE/'bin'/n) for n in names}
  require(report['binaries_after']==before,'binarychanged')
 except BaseException as e:report.update(status='failed',finalization_error=f'{type(e).__name__}: {e}')
 report['ended_ns']=time.time_ns();flush()
raise SystemExit(0 if report['status']=='passed' else 1)
