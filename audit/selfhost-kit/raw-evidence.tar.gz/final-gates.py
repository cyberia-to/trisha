import hashlib,json,pathlib,subprocess,sys,time
R=pathlib.Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap')
root=R/'trisha-selfhost-kit'; output=R/'measurements/selfhost-kit'; source=output/'frozen-source.json'
identity=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
frozen=json.loads(source.read_bytes())
assert all(identity(root/p)==x for p,x in frozen['files'].items())
joy=R/'measurements/coordinated-soft3-release-2/candidate пробел/bin/joy'
trident=R/'measurements/coordinated-soft3-release-2/unpacked/cyber-source/trident'
rehearsal=output/'rehearsal-1/kit'
common=['--rehearsal',str(rehearsal),'--trident',str(trident),'--joy',str(joy),'-v']
commands=[('kit-normal',[sys.executable,'-B','-W','error',str(root/'scripts/test_selfhost_kit.py'),*common]),('kit-optimized',[sys.executable,'-B','-O','-W','error',str(root/'scripts/test_selfhost_kit.py'),*common])]
for name in ('test_archive_source.py','test_snapshot_source.py','test_verify_source.py','test_package_binaries.py','test_check_baselines.py'):
 commands.append((name,[sys.executable,'-B','-W','error',str(root/'scripts'/name),'-v']))
commands.append(('actual-candidate-smoke',[sys.executable,'-B','-W','error',str(root/'scripts/selfhost-kit.py'),'smoke','--kit',str(rehearsal),'--joy',str(joy),'--trident',str(trident),'--output',str(output/'final-candidate-smoke пробел'),'--rehearsal']))
commands.append(('diff-check',['git','diff','--check']))
report=dict(status='running',base_revision=frozen['base_revision'],source=identity(source),files=frozen['files'],joy=identity(joy),candidate=identity(joy.parent.parent/'candidate.json'),commands=[],scope='Kit guards, routing-only packaging and actual historical-C2 rehearsal; accepted kit positive pending original36 authority')
for name,argv in commands:
 log=output/('final-'+name+'.log');start=time.time_ns()
 with log.open('xb') as stream:r=subprocess.run(argv,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
 report['commands'].append(dict(name=name,argv=argv,cwd=str(root),exit_code=r.returncode,started_ns=start,ended_ns=time.time_ns(),log=dict(path=log.name,**identity(log))))
 (output/'final-gates.json').write_text(json.dumps(report,indent=2)+'\n')
 print(name,r.returncode,flush=True)
 if r.returncode:break
report['source_unchanged']=all(identity(root/p)==x for p,x in frozen['files'].items())
report['joy_unchanged']=identity(joy)==report['joy'];report['status']='passed' if all(c['exit_code']==0 for c in report['commands']) and len(report['commands'])==len(commands) and report['source_unchanged'] and report['joy_unchanged'] else 'failed'
(output/'final-gates.json').write_text(json.dumps(report,indent=2)+'\n')
