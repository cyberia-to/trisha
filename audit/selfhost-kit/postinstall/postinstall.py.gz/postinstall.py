import hashlib,json,os,pathlib,subprocess,time
R=pathlib.Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap');family=R/'portable-native-smoke';root=family/'trisha-kit-install';out=R/'measurements/selfhost-kit/postinstall';out.mkdir(exist_ok=False)
env=dict(os.environ,RUSTUP_TOOLCHAIN='1.89.0',CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR=str(out/'target'),PYTHONDONTWRITEBYTECODE='1');env.pop('RUSTFLAGS',None);env.pop('CARGO_ENCODED_RUSTFLAGS',None)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=dict(scope='Postcommit isolated local Trisha CLI rebuild, no new runtime/proof acceptance',status='running',revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),commands=[])
def run(name,args):
 log=out/(name+'.log');start=time.time_ns()
 with log.open('xb') as f:r=subprocess.run(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 report['commands'].append(dict(argv=args,cwd=str(root),environment={k:env[k] for k in ('RUSTUP_TOOLCHAIN','CARGO_BUILD_JOBS','CARGO_TARGET_DIR','PYTHONDONTWRITEBYTECODE')},started_ns=start,ended_ns=time.time_ns(),exit_code=r.returncode,log=dict(path=log.name,bytes=log.stat().st_size,sha256=sha(log))))
 (out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
 if r.returncode:raise RuntimeError(name+' failed')
 return log
try:
 run('vendor',['/opt/homebrew/bin/nu','--no-config-file','patches/apply.nu'])
 run('rustc',['/Users/master/.cargo/bin/rustup','run','1.89.0','rustc','-vV'])
 metadata=run('metadata',['/Users/master/.cargo/bin/rustup','run','1.89.0','cargo','metadata','--format-version','1','--locked','--offline'])
 data=json.loads(metadata.read_bytes());paths=[pathlib.Path(p['manifest_path']).resolve() for p in data['packages'] if p['source'] is None];assert all(p.is_relative_to(family.resolve()) for p in paths)
 names=sorted({p.relative_to(family.resolve()).parts[0] for p in paths})
 def states():
  values={}
  for name in names:
   path=family/name;values[name]=dict(revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=path,text=True).strip(),status=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=path,text=True),path=str(path.resolve()))
  return values
 report['local_packages']=[str(p) for p in paths];report['before']=states();assert all(not p['status'] for p in report['before'].values())
 (out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
 run('install',['/Users/master/.cargo/bin/rustup','run','1.89.0','cargo','install','--path','cli','--root',str(out/'install'),'--locked','--offline','--force'])
 report['after']=states();assert report['before']==report['after']
 binary=out/'install/bin/trisha';report['binary']=dict(path=str(binary),bytes=binary.stat().st_size,sha256=sha(binary))
 run('version',[str(binary),'--version']);report['status']='passed'
except BaseException as error:
 report.update(status='failed',error=f'{type(error).__name__}: {error}');raise
finally:
 (out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
