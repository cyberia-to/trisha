"""Retain actual accepted-kit delivery once, with exact aliases and external identities."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

ROOT=Path(__file__).resolve().parent
R=ROOT.parent.parent
D=ROOT/'delivery'
OUT=ROOT/'retention'

def ident(path):
 with path.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(bytes=path.stat().st_size,sha256=digest)
def load(p):return json.loads(p.read_bytes())
def write(p,v):
 with p.open('x') as f:f.write(json.dumps(v,indent=2)+'\n')
def rows(p,v):
 with p.open('x') as f:f.write('[\n'+',\n'.join(json.dumps(r,sort_keys=True,ensure_ascii=False) for r in v)+'\n]\n')

run=load(D/'receipt.json')
if run['status']!='passed':raise ValueError('delivery not passed')
OUT.mkdir()
kit={}
with tarfile.open(D/'selfhost-kit.tar.gz') as t:
 for member in t:
  if member.isfile():
   raw=t.extractfile(member).read();kit[member.name.removeprefix('trident-selfhost/')]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
selected={};aliases=[];external=[];delivery=[]
def add(name,path):
 if name in selected or path.is_symlink() or not path.is_file():raise ValueError('invalid selection '+name)
 selected[name]=path
for path in sorted(D.rglob('*')):
 if not path.is_file():continue
 name=path.relative_to(D).as_posix();row=dict(path=name,original_path=str(path),**ident(path));member=None
 for prefix in ['kit/','assembly/kit/','unpacked/cyber-tools/share/trident-selfhost/']:
  if name.startswith(prefix):member=name[len(prefix):]
 if path.name=='compiler.dag':member='compiler.dag'
 if member is not None:
  if {k:row[k] for k in ('bytes','sha256')}!=kit[member]:raise ValueError('kit alias changed')
  aliases.append(dict(**row,archive='selfhost-kit.tar.gz',member='trident-selfhost/'+member));row['retained']='canonical-kit-alias'
 elif name=='selfhost-kit.tar.gz':
  shutil.copyfile(path,OUT/'selfhost-kit.tar.gz');row['retained']='selfhost-kit.tar.gz'
 elif name in ['package.tar.gz','repack.tar.gz'] or name.startswith('unpacked/cyber-tools/bin/'):
  external.append(dict(**row,role='delivery binary container/executable'));row['retained']='external-identity'
 else:
  add('delivery/'+name,path);row['retained']='evidence.tar.gz:delivery/'+name
 delivery.append(row)
for path in sorted(ROOT.iterdir()):
 if path.is_file():add('driver/'+path.name,path)
S=R/'trisha-selfhost-kit/scripts'
for name in ['selfhost-kit.py','selfhost_kit.py','selfhost_kit_assembly.py','package-binaries.nu','archive-source.py','verify-source.py','native-candidate.py']:
 add('implementation/trisha/'+name,S/name)
add('implementation/trident/prepare-selfhost-source.py',R/'portable-native-smoke/trident-selfbuild-guide/scripts/prepare-selfhost-source.py')
for name in ['receipt.json','stdout','package.json','preparation.json','admission.json']:
 add('previous-full-execution/'+name,R/'measurements/selfhost-source-execution'/name)
T=R/'measurements/coordinated-soft3-release-3'
for name in ['prepare.json','build.json','candidate пробел/candidate.json','candidate пробел/source-verification.json','smoke пробел/smoke.json','unpacked/cyber-source/sources.json']:
 add('runtime-provenance/'+name,T/name)
for path,role in [(T/'source-export.tar.gz','original committed coordinated source archive')]+[(T/'candidate пробел/bin'/name,'original installed '+name) for name in ['joy','trident','trident-lsp','trisha']]:
 external.append(dict(path=str(path),original_path=str(path),role=role,**ident(path)))
manifest=[dict(path=name,original_path=str(path),**ident(path)) for name,path in sorted(selected.items())]
stored={}
with (OUT/'evidence.tar.gz').open('xb') as stream:
 with gzip.GzipFile(fileobj=stream,mode='wb',filename='',mtime=0,compresslevel=9) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
   for row in manifest:
    info=tarfile.TarInfo(row['path']);info.mode=0o644;key=(row['bytes'],row['sha256'])
    if key in stored:
     info.type=tarfile.LNKTYPE;info.linkname=stored[key];tar.addfile(info)
    else:
     stored[key]=row['path'];info.size=row['bytes']
     with selected[row['path']].open('rb') as incoming:tar.addfile(info,incoming)
seen=set()
with tarfile.open(OUT/'evidence.tar.gz') as tar:
 for member in tar:
  if member.name in seen or member.name not in selected:raise ValueError('archive member set')
  if tar.extractfile(member).read()!=selected[member.name].read_bytes():raise ValueError('raw original byte mismatch')
  seen.add(member.name)
if seen!=selected.keys():raise ValueError('archive completeness')
if ident(OUT/'selfhost-kit.tar.gz')!=run['kit_archive']:raise ValueError('original accepted kit archive')
rows(OUT/'evidence-files.json',manifest);rows(OUT/'delivery-files.json',delivery)
rows(OUT/'canonical-kit-aliases.json',aliases);rows(OUT/'external-files.json',external)
receipt=dict(schema='trident/accepted-kit-retention/v1',status='retained',original_delivery=ident(D/'receipt.json'),
             source_revision='4b81af3baf01180d95113e5d69ed8d7e5e69eb1e',driver_sha256=run['driver']['sha256'],
             kit_archive=dict(path='selfhost-kit.tar.gz',**ident(OUT/'selfhost-kit.tar.gz')),
             evidence_archive=dict(path='evidence.tar.gz',**ident(OUT/'evidence.tar.gz')),
             evidence_members=len(manifest),evidence_raw_bytes=sum(r['bytes'] for r in manifest),
             delivery_files=len(delivery),delivery_raw_bytes=sum(r['bytes'] for r in delivery),
             canonical_aliases=len(aliases),external_identities=len(external),
             exact_archived_original_bytes=True,exact_original_accepted_kit_bytes=True,
             original_final36_verification=run['original_validation'],
             immutable_original_ci_dependency=str(R/'measurements/ci-phases-final-acceptance'),
             original_ci_scope='Full original ZIP/API/store/tree chain remains retained by Trident; fresh authority report and exact references retained here',
             scope='Accepted portable kit and local installed/unpacked runtime compatibility; prior full self-build reused through exact inputs; no new SH6 or compilation proof')
write(OUT/'receipt.json',receipt)
print(json.dumps(receipt,sort_keys=True))
