# Accepted-kit delivery driver, awaiting original final36 acceptance

Status: prepared, not executed. The read-only preflight verifies the clean
Trisha PR19 head `4b81af3baf01180d95113e5d69ed8d7e5e69eb1e`, exact relevant
script Git blobs, the pinned validator/helper, existing third installed four
binaries, immutable source/smoke receipts and three guide inputs. No assembler,
packager or guest command has been run by this driver. No accepted kit exists
here yet. Original rehearsal measurements remain unchanged.

`run.py` defaults to printing its plan. Do not use `--execute` until root has
reported that the original final36 authority passed. The expected original
inputs are `../ci-phases-final-acceptance/{restored,indices.json,validation}`.
Root supplies the independently checked SHA-256 of
`validation/verification.json`. The driver derives the eight explicit absolute
input paths, final index SHA and original aggregate ID from that receipt's
actual validator command. It does not invent archive IDs or replace the
original aggregate with a locally synthesized verdict.

After the explicit final36-passed message:

```sh
python3 -B -W error run.py --execute \
  --validation-sha256 ORIGINAL_VERIFICATION_SHA256 \
  --producer-name bootstrap-phase-aarch64-apple-darwin-repeat-1-producer-attempt-1
```

The default output is a fresh `delivery/` child of this directory. Existing
outputs are rejected. Another fresh direct child can be named with `--output`;
failed evidence is preserved and never overwritten or silently retried.

The executable sequence uses the frozen PR19 production tools:

1. `selfhost-kit.py assemble` invokes the exact original 36-phase validator
   SHA `72cd11ec62e410e908590a785c79011989ea2c6c32872c5db31d72a62947c0ec`
   into fresh validation evidence, then selects the original explicit C2 role,
   inventory and fixed-point records. The previous final receipt is only
   preflight/input routing; this fresh authority invocation remains required.
2. Production `unpack` and `check` validate the resulting archive and exact
   third candidate Trident sources. No rehearsal flag is supplied.
3. Third installed Joy SHA
   `4035bca898e760666206f445c939c784ea248bff4f82c2c4f0a75254c3c48885`
   runs the real five-command smoke (atom13 plus guest rejection preserving
   output), followed by the production smoke-receipt checker.
4. The frozen production packager packages and repackages the original third
   installed candidate and its existing complete installed smoke. Archive
   bytes must match exactly. The unchanged four binaries are checked after
   extraction using the existing native-candidate extractor.
5. The unpacked Joy repeats the five-command kit smoke and receipt check. The
   shipped kit manifest must equal the separately assembled original kit.
6. The reviewed Trident helper SHA
   `4f2381880f7da77265ed562cb99bc0e7bcad4c5f7df28f8c62bf7a37f55c3711`
   prepares all frozen sources in default accepted mode. An empty-PATH cheap
   `pack-job` uses the exact published 20B/1B/3145728/10B/65536/7200000/16777216
   host profile. C2, JOB1 and package manifest must equal the immutable inputs
   of the already successful 22-minute full self-build. Its actual Joy binary
   must also match. This reuses that observed result only through byte-exact
   compiler/JOB/runtime identity; it performs no second heavy guest run.
7. The production full source guard runs again. Start/end identities, actual
   argv/cwd/exit/log bytes, original verification/index identities and all
   failures remain in the new delivery receipt.

The accepted kit's original SH6 provenance and this local binary package are
separate claims. The original installed candidate remains the committed third
local rehearsal source closure, with its unchanged four-binary proof corpus.
This driver does not build code, regenerate proofs, alter source inputs, merge,
publish, change runtime/compiler limits or claim a new native matrix or
SH7/SH8 result. Package/proof/CPU acceptance beyond the existing installed
smoke remains owned by its original gate receipts.
