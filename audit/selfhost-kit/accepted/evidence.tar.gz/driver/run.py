"""Prepare or run the real accepted-kit delivery; execution awaits root's final36 verdict."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode = True
R = Path('/Users/master/cyber/.worktrees/selfhost-0.4-full-bootstrap')
HERE = Path(__file__).resolve().parent
TRISHA = R / 'trisha-selfhost-kit'
REVISION = '4b81af3baf01180d95113e5d69ed8d7e5e69eb1e'
SCRIPTS = TRISHA / 'scripts'
HELPER = R / 'portable-native-smoke/trident-selfbuild-guide/scripts/prepare-selfhost-source.py'
HELPER_SHA = '4f2381880f7da77265ed562cb99bc0e7bcad4c5f7df28f8c62bf7a37f55c3711'
VALIDATOR = R / 'trident/audit/self-hosting/bootstrap-results/run-36382085561/final-validation/verify-final-matrix.py'
VALIDATOR_SHA = '72cd11ec62e410e908590a785c79011989ea2c6c32872c5db31d72a62947c0ec'
FINAL = R / 'measurements/ci-phases-final-acceptance'
GUIDE = R / 'trident/audit/self-hosting/bootstrap-results/cli-guide'
THIRD = R / 'measurements/coordinated-soft3-release-3'
CANDIDATE = THIRD / 'candidate пробел'
SMOKE = THIRD / 'smoke пробел/smoke.json'
PREVIOUS = R / 'measurements/selfhost-source-execution/receipt.json'
PREPARED = R / 'measurements/selfhost-source-preparation/final/prepared'
PATH_KEYS = ('restored', 'stores', 'indices', 'inputs', 'runner-directory', 'expected', 'aggregate-job', 'final-run')
FLAGS = ['--arena-nodes', '1000000000', '--budget', '20000000000', '--frames', '65536',
         '--time-ms', '7200000', '--validation-visits', '16777216',
         '--resident-nodes', '3145728', '--collection-work', '10000000000']


def require(value, label):
    if not value:
        raise ValueError(label)


def identity(path):
    require(path.is_file() and not path.is_symlink(), 'ordinary file: ' + str(path))
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(bytes=path.stat().st_size, sha256=digest)


def load(path):
    require(path.stat().st_size <= 32 << 20, 'bounded JSON')
    return json.loads(path.read_bytes())


def write(path, value):
    with path.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def git(*args):
    return subprocess.check_output(['git', '-C', str(TRISHA), *args], text=True).strip()


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def frozen_inputs():
    require(git('rev-parse', 'HEAD') == REVISION and not git('status', '--porcelain'), 'clean frozen PR19')
    names = ['selfhost-kit.py', 'selfhost_kit.py', 'selfhost_kit_assembly.py', 'package-binaries.nu',
             'archive-source.py', 'verify-source.py', 'native-candidate.py']
    scripts = {}
    for name in names:
        raw = subprocess.check_output(['git', '-C', str(TRISHA), 'show', REVISION + ':scripts/' + name])
        require(raw == (SCRIPTS / name).read_bytes(), 'pinned PR19 script: ' + name)
        scripts[name] = identity(SCRIPTS / name)
    require(identity(VALIDATOR)['sha256'] == VALIDATOR_SHA, 'pinned acceptance authority')
    require(identity(HELPER)['sha256'] == HELPER_SHA, 'reviewed transport helper')
    candidate = load(CANDIDATE / 'candidate.json')
    source = Path(candidate['source'])
    require(source.is_absolute(), 'original source root')
    binaries = {row['name']: identity(CANDIDATE / 'bin' / row['name']) for row in candidate['binaries']}
    require(set(binaries) == {'joy', 'trident', 'trident-lsp', 'trisha'}, 'unchanged four binaries')
    require(all(binaries[row['name']]['sha256'] == row['sha256'] for row in candidate['binaries']), 'original installed binaries')
    require(binaries['joy']['sha256'] == '4035bca898e760666206f445c939c784ea248bff4f82c2c4f0a75254c3c48885', 'reviewed installed Joy')
    return dict(revision=REVISION, scripts=scripts, helper=identity(HELPER), validator=identity(VALIDATOR),
                candidate=identity(CANDIDATE / 'candidate.json'), binaries=binaries,
                source=str(source), source_manifest=identity(source / 'sources.json'),
                source_verification=identity(CANDIDATE / 'source-verification.json'),
                installed_smoke=identity(SMOKE), previous_full_execution=identity(PREVIOUS),
                guide={name: identity(GUIDE / name) for name in ('sample.tri', 'package.json', 'zero.dag')})


def authority_config(proof_path, expected_sha, producer):
    require(identity(proof_path)['sha256'] == expected_sha, 'externally pinned original final verification')
    proof = load(proof_path)
    require(proof['status'] == 'passed' and proof['validator_sha256'] == VALIDATOR_SHA, 'original final36 completion preflight')
    command = proof['command']
    require(len(command) >= 2 and identity(Path(command[1]))['sha256'] == VALIDATOR_SHA, 'original validator command')
    pairs = command[2:]
    require(len(pairs) % 2 == 0, 'exact original argument pairs')
    keys = [pairs[i].removeprefix('--') for i in range(0, len(pairs), 2)]
    require(len(keys) == len(set(keys)) and all(pairs[i].startswith('--') for i in range(0, len(pairs), 2)), 'unique original options')
    config = dict(zip(keys, pairs[1::2]))
    require(set(config) == {*PATH_KEYS, 'indices-sha256', 'aggregate-id', 'output'}, 'complete original command')
    require(Path(config.pop('output')).resolve() == proof_path.parent.resolve(), 'original validation output')
    require(all(Path(config[k]).is_absolute() for k in PATH_KEYS), 'absolute authority inputs')
    require(Path(config['restored']).resolve() == FINAL / 'restored' and Path(config['indices']).resolve() == FINAL / 'indices.json', 'declared final input tree')
    require(identity(Path(config['indices']))['sha256'] == config['indices-sha256'], 'original index snapshot')
    require(producer in {row['name'] for row in proof['phases']} and '-producer-attempt-' in producer, 'explicit original producer')
    config.update({'aggregate-id': int(config['aggregate-id']), 'producer-name': producer})
    return config


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true', help='only after explicit final36-passed authorization')
    parser.add_argument('--validation-sha256', help='external SHA of original completed final verification.json')
    parser.add_argument('--producer-name', default='bootstrap-phase-aarch64-apple-darwin-repeat-1-producer-attempt-1')
    parser.add_argument('--output', type=Path, default=HERE / 'delivery')
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps(dict(status='prepared-not-executed', root_authorization_required='final36 passed',
                              input=str(FINAL), output=str(args.output), producer=args.producer_name,
                              authority=VALIDATOR_SHA, kit_revision=REVISION,
                              routes=['fresh original authority + assemble', 'production unpack/check',
                                      'installed five-route Joy smoke', 'package/repack exact equality',
                                      'unpacked five-route Joy smoke', 'default accepted-source preparation + exact JOB bridge'],
                              heavy_guest_runs=0, scope='driver preparation only'), indent=2))
        return
    require(args.validation_sha256 is not None, 'explicit original verification SHA required')
    require(os.environ.get('GITHUB_ACTIONS') != 'true', 'local authority replay only')
    out = args.output.absolute()
    require(out.parent.resolve() == HERE and not out.exists() and not out.is_symlink(), 'fresh owned output')
    start = frozen_inputs()
    proof_path = FINAL / 'validation/verification.json'
    config = authority_config(proof_path, args.validation_sha256, args.producer_name)
    for path in [*[Path(config[k]) for k in PATH_KEYS], SCRIPTS, HELPER, CANDIDATE, GUIDE, PREPARED]:
        require(not out.resolve().is_relative_to(path.resolve()) and not path.resolve().is_relative_to(out.resolve()), 'output/input overlap')
    nu_path = shutil.which('nu')
    require(nu_path is not None, 'installed Nushell required')
    nu = Path(nu_path).resolve()
    require(nu.is_absolute(), 'installed absolute Nushell required')
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    out.mkdir()
    report = dict(schema='trident/accepted-kit-delivery-measurement/v1', status='running', started_ns=time.time_ns(),
                  driver=identity(Path(__file__)), inputs_start=start, commands=[],
                  original_validation=identity(proof_path), nu=dict(path=str(nu), **identity(nu)),
                  python=dict(path=sys.executable, resolved=str(Path(sys.executable).resolve()), version=sys.version,
                              **identity(Path(sys.executable).resolve())),
                  scope='Accepted kit + existing installed runtime compatibility; no new SH6 run or compilation proof')
    def flush():
        (out / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
    def run(name, argv, selected_env=env, timeout=1800):
        row = dict(name=name, argv=list(map(str, argv)), cwd=str(out), status='running', started_ns=time.time_ns())
        report['commands'].append(row); flush()
        try:
            with (out / (name + '.stdout')).open('xb') as stdout, (out / (name + '.stderr')).open('xb') as stderr:
                result = subprocess.run(row['argv'], cwd=out, env=selected_env, stdout=stdout, stderr=stderr, timeout=timeout)
            row.update(status='completed', exit_code=result.returncode)
            require(result.returncode == 0, name + ' failed')
        except BaseException as error:
            row.update(status='failed', error=type(error).__name__ + ': ' + str(error)); raise
        finally:
            row.update(ended_ns=time.time_ns(), **{k: identity(out / (name + '.' + k)) for k in ('stdout', 'stderr')}); flush()
    try:
        write(out / 'authority-config.json', config)
        source = Path(start['source']) / 'trident'
        kit_cli = [sys.executable, '-B', '-W', 'error', SCRIPTS / 'selfhost-kit.py']
        archive = out / 'selfhost-kit.tar.gz'
        run('assemble', [*kit_cli, 'assemble', '--trident', source, '--guide', GUIDE,
                         '--validator', VALIDATOR, '--config', out / 'authority-config.json',
                         '--work', out / 'assembly', '--output', archive])
        digest = identity(archive)['sha256']
        kit = out / 'kit'
        run('unpack-kit', [*kit_cli, 'unpack', '--archive', archive, '--sha256', digest, '--trident', source, '--output', kit])
        run('check-kit', [*kit_cli, 'check', '--kit', kit, '--trident', source])
        run('installed-smoke', [*kit_cli, 'smoke', '--kit', kit, '--trident', source,
                               '--joy', CANDIDATE / 'bin/joy', '--output', out / 'installed-smoke'])
        run('check-installed-smoke', [*kit_cli, 'check', '--kit', kit, '--trident', source,
                                     '--joy', CANDIDATE / 'bin/joy', '--receipt', out / 'installed-smoke/receipt.json'])
        for name in ('package', 'repack'):
            run(name, [nu, '--no-config-file', SCRIPTS / 'package-binaries.nu', CANDIDATE, out / (name + '.tar.gz'),
                       '--smoke', SMOKE, '--selfhost-kit', archive, '--selfhost-kit-sha256', digest,
                       '--selfhost-smoke', out / 'installed-smoke/receipt.json'])
        require(identity(out / 'package.tar.gz') == identity(out / 'repack.tar.gz'), 'deterministic binary package')
        module(SCRIPTS / 'native-candidate.py', 'native_candidate').extract(out / 'package.tar.gz', out / 'unpacked')
        unpacked = out / 'unpacked/cyber-tools'
        for name, row in start['binaries'].items():
            require(identity(unpacked / 'bin' / name) == row, 'unpacked binary: ' + name)
        shipped = unpacked / 'share/trident-selfhost'
        require(identity(shipped / 'kit.json') == identity(kit / 'kit.json'), 'packaged original kit')
        run('unpacked-smoke', [*kit_cli, 'smoke', '--kit', shipped, '--trident', source,
                              '--joy', unpacked / 'bin/joy', '--output', out / 'unpacked-smoke'])
        run('check-unpacked-smoke', [*kit_cli, 'check', '--kit', shipped, '--trident', source,
                                    '--joy', unpacked / 'bin/joy', '--receipt', out / 'unpacked-smoke/receipt.json'])
        (out / 'empty-path').mkdir()
        empty_env = dict(env, PATH=str(out / 'empty-path'))
        require(not any(shutil.which(n, path=empty_env['PATH']) for n in ['cargo', 'rustc', 'trident']), 'empty compiler-toolchain PATH')
        prepared = out / 'prepared'
        run('prepare-default', [sys.executable, '-B', '-W', 'error', HELPER, '--kit', shipped,
                                '--kit-manifest-sha256', identity(shipped / 'kit.json')['sha256'],
                                '--source-root', source, '--output', prepared], empty_env)
        run('pack-full-source', [unpacked / 'bin/joy', 'pack-job', '--compiler', prepared / 'compiler.dag',
                                '--manifest', prepared / 'package.json', '--output', prepared / 'job.dag', *FLAGS], empty_env)
        require(load(prepared / 'receipt.json')['kit_status'] == 'accepted', 'actual accepted default preparation')
        old = load(PREVIOUS)
        require(old['status'] == 'passed' and old['non_time_execution_fields_equal'] is True, 'reviewed prior full execution')
        bridge = {}
        for name in ('compiler.dag', 'job.dag', 'package.json'):
            require((prepared / name).read_bytes() == (PREPARED / name).read_bytes(), 'exact prior input bridge: ' + name)
            bridge[name] = identity(prepared / name)
        require(bridge['compiler.dag'] == old['inputs_start']['files']['compiler.dag'] and
                bridge['job.dag'] == old['inputs_start']['files']['job.dag'], 'reviewed run receipt inputs')
        require(identity(unpacked / 'bin/joy') == old['binary_end'], 'same actual runtime as full execution')
        run('source-guard-after', [sys.executable, '-B', '-W', 'error', SCRIPTS / 'verify-source.py', source.parent,
                                   '--expect', CANDIDATE / 'source-verification.json'])
        require(identity(proof_path) == report['original_validation'] and
                identity(Path(config['indices']))['sha256'] == config['indices-sha256'], 'authority inputs unchanged')
        report.update(status='passed', kit_archive=identity(archive), kit_manifest=identity(kit / 'kit.json'),
                      binary_archive=identity(out / 'package.tar.gz'), deterministic_package=True,
                      prepared_bridge=bridge, reused_full_execution=identity(PREVIOUS), additional_heavy_guest_runs=0,
                      qualification='Actual accepted-kit commands; prior full self-build reused only through exact C2/JOB/runtime identity')
    except BaseException as error:
        report.update(status='failed', error=type(error).__name__ + ': ' + str(error)); raise
    finally:
        report['ended_ns'] = time.time_ns()
        try:
            report['inputs_end'] = frozen_inputs()
            if report['inputs_end'] != start: report['status'] = 'inputs-changed'
        except BaseException as error:
            report.update(status='inputs-changed', end_input_error=type(error).__name__ + ': ' + str(error))
        flush()
    require(report['status'] == 'passed', 'delivery completion')


if __name__ == '__main__':
    main()
