"""Independent supplementary bridge and raw-log checks; no subprocess execution."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('delivery_driver',ROOT/'run.py')
D=importlib.util.module_from_spec(spec);spec.loader.exec_module(D)
O=ROOT/'delivery'
r=D.load(O/'receipt.json');old=D.load(D.PREVIOUS)
D.require(r['status']=='passed' and r['inputs_start']==r['inputs_end'],'successful unchanged delivery')
D.require(old['status']=='passed' and old['host_flags']==D.FLAGS,'prior full execution exact published host profile')
checks={}
for name in ('compiler.dag','job.dag','package.json'):
 row=D.identity(O/'prepared'/name)
 D.require(row==old['inputs_start']['files'][name]==old['inputs_end']['files'][name],'prior receipt exact input: '+name)
 D.require((O/'prepared'/name).read_bytes()==(D.PREPARED/name).read_bytes(),'prior input actual bytes: '+name)
 checks[name]=row
D.require(D.identity(O/'unpacked/cyber-tools/bin/joy')==old['binary_end'],'actual prior runtime bytes')
D.require((O/'package.tar.gz').read_bytes()==(O/'repack.tar.gz').read_bytes(),'actual archive byte equality')
for row in r['commands']:
 D.require(row['status']=='completed' and row['exit_code']==0,'all real command results')
 for stream in ('stdout','stderr'):
  D.require(D.identity(O/(row['name']+'.'+stream))==row[stream],'unaltered raw command logs')
prepare=next(row for row in r['commands'] if row['name']=='prepare-default')
D.require('--rehearsal' not in prepare['argv'],'actual default accepted mode')
prep=D.load(O/'prepared/receipt.json')
D.require(prep['kit_status']=='accepted' and len(prep['sources'])==94,'actual accepted full source closure')
for name,row in prep['files'].items():D.require(D.identity(O/'prepared'/name)==row,'actual prepared file')
for row in prep['sources'].values():D.require(D.identity(O/'prepared'/row['copy'])=={k:row[k] for k in ('bytes','sha256')},'actual copied source')
report=dict(status='passed',scope='Read-only extra bindings, no new guest execution',driver=D.identity(ROOT/'run.py'),delivery=D.identity(O/'receipt.json'),
            previous_full_execution=D.identity(D.PREVIOUS),published_host_flags_equal=True,all_three_previous_receipt_inputs_equal=True,
            same_actual_joy=True,byte_exact_repacked_archives=True,default_accepted_preparation=True,
            copied_sources=94,copied_source_bytes=sum(row['bytes'] for row in prep['sources'].values()),inputs=checks,
            commands=12,additional_heavy_guest_runs=0)
D.write(ROOT/'postcheck.json',report)
print(json.dumps(report,sort_keys=True))
