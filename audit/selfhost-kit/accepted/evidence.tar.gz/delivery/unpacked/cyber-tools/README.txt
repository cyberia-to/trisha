Cyber compiler and warriors — tested local binary candidate

Extract cyber-tools and add its bin directory to PATH. Keep trident, trident-lsp, trisha and joy together. Z3 is an optional dependency for trident audit --z3. Inspect each command with --version and --help. Exact binary SHA256 identities are in candidate.json and smoke.json. The smoke receipt records the tested platform; this archive is not portable to arbitrary OS/CPU combinations.

share/trident-selfhost contains the portable accepted compiler and its three guide inputs; follow its README.md to compile through Joy. selfhost-kit.json pins the separately assembled archive and selfhost-smoke.json binds this installed Joy. share/trisha-release-smoke contains public test certificates, not wallet data. licenses contains the three project licenses.

Full installed compiler/warrior smoke passed for these binary hashes. This includes recursive and public/private/state proof paths; private state tables are bounded and public. Live Neptune admission/deployment, GPU proving, registry publication and universal formal verification are separate gates. This local archive is not a publication or network action.
