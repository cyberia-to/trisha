# Portable Trident compiler

Status: accepted.

Keep these files together. From this directory with the supplied Joy on PATH:

```sh
joy pack-job --compiler compiler.dag --manifest package.json --output job.dag
joy run-artifact compiler.dag --input job.dag --emit program --output sample.dag
joy run-artifact sample.dag --input zero.dag --output answer.dag
```

The expected result is the canonical atom 13. kit.json pins every payload file.
The compiler is a portable compiler-job NOXDAG artifact; Joy executes it.
Rehearsal status is not release acceptance. Native bootstrap provenance and
installed-runtime smoke are separate from compilation proofs (SH7/SH8).
